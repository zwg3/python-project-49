#!/usr/bin/env python3
from Brain_games.games.even_game import even_game
from Brain_games.game_start import game_starter


def main():
    game_starter(even_game)


if __name__ == "__main__":
    main()
