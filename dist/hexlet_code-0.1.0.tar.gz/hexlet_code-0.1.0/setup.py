# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts', 'brain_games.scripts.games']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.games.brain_calc:main',
                     'brain-even = brain_games.scripts.games.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.games.brain_gcd:main',
                     'brain-prime = brain_games.scripts.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'A number of games run from the terminal',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/zwg3/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zwg3/python-project-49/actions)\n\n###Codeclimate maintainability badge:\n<a href="https://codeclimate.com/github/zwg3/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4c54ad22338cf823bbf3/maintainability" /></a>\n\n###Even numbers game demonstration\nhttps://asciinema.org/a/H4N5wUxO8uQDPiNLLAIXI86L3\n\n###Calculator game demonstration\nhttps://asciinema.org/a/G5L4LfbdR3TTutdTm3vsRLcif\n\n###Greatest common divisor game demonstration\nhttps://asciinema.org/a/Zcda5WmT3bmmGHB7dAuHJXxxo\n\n###Arithmethic progression game demonstration\nhttps://asciinema.org/a/QL57dKgJ216xLSv6MscOPcLjJ\n\n###Prime numbers game demonstration\nhttps://asciinema.org/a/KqL9hZVEoKa15hEyfZyI5UhMx\n\n',
    'author': 'zwg',
    'author_email': 'zwg.work.mail@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/zwg3/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
