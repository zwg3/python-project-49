### Hexlet tests and linter status:
[![Actions Status](https://github.com/zwg3/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zwg3/python-project-49/actions)

###Codeclimate maintainability badge:
<a href="https://codeclimate.com/github/zwg3/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4c54ad22338cf823bbf3/maintainability" /></a>

###Even numbers game demonstration
https://asciinema.org/a/uAPDJp2edkrftyiLEkqGpO6Ms

###Calculator game demonstration
https://asciinema.org/a/KAAjzPl7IisLSFrIG8tZCTYUU

###Greatest common divisor game demonstration


###Arithmethic progression game demonstration

