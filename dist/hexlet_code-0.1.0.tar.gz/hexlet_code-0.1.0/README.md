### Hexlet tests and linter status:
[![Actions Status](https://github.com/zwg3/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/zwg3/python-project-49/actions)

###Codeclimate maintainability badge:
<a href="https://codeclimate.com/github/zwg3/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4c54ad22338cf823bbf3/maintainability" /></a>

###Even numbers game demonstration
https://asciinema.org/a/H4N5wUxO8uQDPiNLLAIXI86L3

###Calculator game demonstration
https://asciinema.org/a/G5L4LfbdR3TTutdTm3vsRLcif

###Greatest common divisor game demonstration
https://asciinema.org/a/Zcda5WmT3bmmGHB7dAuHJXxxo

###Arithmethic progression game demonstration
https://asciinema.org/a/QL57dKgJ216xLSv6MscOPcLjJ

###Prime numbers game demonstration
https://asciinema.org/a/KqL9hZVEoKa15hEyfZyI5UhMx

